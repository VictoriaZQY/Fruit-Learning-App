package com.example.fruitlearningapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * This class set the fruit images as clickable
 *     by adding a listener to each fruit image.
 */

public class FruitAdapter extends RecyclerView.Adapter<FruitAdapter.FruitViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Fruit fruit);
    }

    private Context context;
    private List<Fruit> fruitList;
    private OnItemClickListener listener;

    public FruitAdapter(Context context, List<Fruit> fruitList, OnItemClickListener listener) {
        this.context = context;
        this.fruitList = fruitList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FruitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_fruit, parent, false);
        return new FruitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FruitViewHolder holder, int position) {
        Fruit fruit = fruitList.get(position);
        holder.bind(fruit, listener);
    }

    @Override
    public int getItemCount() {
        return fruitList.size();
    }

    public static class FruitViewHolder extends RecyclerView.ViewHolder {
        TextView fruitName;
        ImageView fruitImage;

        public FruitViewHolder(@NonNull View itemView) {
            super(itemView);
            fruitName = itemView.findViewById(R.id.fruitName);
            fruitImage = itemView.findViewById(R.id.fruitImage);
        }

        public void bind(final Fruit fruit, final OnItemClickListener listener) {
            fruitName.setText(fruit.getName());
            fruitImage.setImageResource(fruit.getImageResId());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(fruit);
                }
            });
        }
    }
}

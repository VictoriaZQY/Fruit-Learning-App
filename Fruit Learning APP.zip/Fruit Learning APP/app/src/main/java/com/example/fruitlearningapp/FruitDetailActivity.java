package com.example.fruitlearningapp;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * This class set up the fruit detail page of the chosen fruit.
 * This page has a back button to go back to the former page.
 *
 * This page has its name and the first letter/character of the word
 *     that fruit name starts with for the fruit.
 */
public class FruitDetailActivity extends AppCompatActivity {
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_fruit_detail);

        ImageView fruitImage = findViewById(R.id.fruitDetailImage);
        TextView fruitName = findViewById(R.id.fruitDetailName);
        TextView fruitLetter = findViewById(R.id.fruitDetailLetter);

        // the button to go back to the former page
        btnBack = findViewById(R.id.btnBack);

        Intent intent = getIntent();
        String name = intent.getStringExtra("fruit_name");
        int imageResId = intent.getIntExtra("fruit_image", -1);

        fruitName.setText(name);
        fruitLetter.setText(name.substring(0, 1).toUpperCase());
        fruitImage.setImageResource(imageResId);

        // set the back button
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // go back to the former page
            }
        });
    }

}


package com.example.fruitlearningapp;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Set the main page. The fruits will be shown as a clickable list.
 * The content's language can be changed automatically according to the system language setting.
 */

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private FruitAdapter adapter;
    private List<Fruit> fruitList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Get the current language on this page
        Locale current = getResources().getConfiguration().locale;

        // Pop up a welcome notification
        // Switch to Mandarin if current page is English, vice versa
        if (current.getLanguage().equals("zh")) {
            Toast.makeText(MainActivity.this,
                    "欢迎来到学习的世界!",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this,
                    "Welcome to the world of learning!",
                    Toast.LENGTH_SHORT).show();
        }

        // set up a recycler view to show the clickable fruit list.
        recyclerView = findViewById(R.id.fruitList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // add items to the list
        fruitList = new ArrayList<>();
        fruitList.add(new Fruit(getString(R.string.apple), R.drawable.apple));
        fruitList.add(new Fruit(getString(R.string.banana), R.drawable.banana));
        fruitList.add(new Fruit(getString(R.string.cherry), R.drawable.cherry));
        fruitList.add(new Fruit(getString(R.string.durian), R.drawable.durian));
        fruitList.add(new Fruit(getString(R.string.orange), R.drawable.orange));

        adapter = new FruitAdapter(this, fruitList, new FruitAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Fruit fruit) {
                // Start the fruit detail Activity of the chosen fruit
                Intent intent = new Intent(MainActivity.this, FruitDetailActivity.class);
                intent.putExtra("fruit_name", fruit.getName());
                intent.putExtra("fruit_image", fruit.getImageResId());
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);
    }
}

package com.example.fruitlearningapp;

/**
 * This class set up a fruit object.
 * This facilitates and clarifies the creation of fruits.
 */
public class Fruit {
    private String name;
    private int imageResId;

    public Fruit(String name, int imageResId) {
        this.name = name;
        this.imageResId = imageResId;
    }

    public String getName() {
        return name;
    }

    public int getImageResId() {
        return imageResId;
    }
}
